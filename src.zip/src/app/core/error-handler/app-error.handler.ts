import { ErrorHandler, inject } from '@angular/core';
import { GlobalErrorService } from '../services/global-error.service';

export class AppErrorHandler implements ErrorHandler {
  private globalError = inject(GlobalErrorService);

  handleError(error: unknown): void {
    this.globalError.handle(error);
  }
}