import { Component, computed, effect, inject, OnInit, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { ToastComponent } from './shared/ui/toast/toast.component';
import { GlobalErrorService } from './core/services/global-error.service';
import { toSignal } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,RouterLink,ToastComponent],
  standalone: true,
  templateUrl: './app.html',
  // styleUrl: './app.scss'
  styleUrls: ['./app.scss'] 
})
export class App implements OnInit{
  protected title = 'ng19-workshop';
  count = signal(0);
  double = computed(()=> this.count()*2);
public globalError = inject(GlobalErrorService);
toast = this.globalError.error;
  constructor(){
    effect(() => {
  if (this.toast()) {
    setTimeout(() => this.globalError.clear(), 3000);
  }
});
  }
  ngOnInit(){
    setTimeout(()=> this.increment(),200);
  }
  increment(){
    this.count.update(v=>v+1);
    console.log("Increment", this.count());
  }
  closeToast() {
  this.globalError.handle('');
}

}
