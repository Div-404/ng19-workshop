export interface User {
  id: number;
  email: string;
  password: string;   // plain text for demo only
}